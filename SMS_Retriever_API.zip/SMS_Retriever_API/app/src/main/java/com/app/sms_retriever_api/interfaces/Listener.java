package com.app.sms_retriever_api.interfaces;

public interface Listener {
    void onSMSReceived(String otp);

    void onTimeOut();
}
