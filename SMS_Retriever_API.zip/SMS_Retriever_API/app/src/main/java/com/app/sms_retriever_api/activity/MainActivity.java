package com.app.sms_retriever_api.activity;

import android.app.PendingIntent;
import android.content.IntentFilter;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.app.sms_retriever_api.R;
import com.app.sms_retriever_api.broadcast.SMSBroadcastReceiver;
import com.app.sms_retriever_api.interfaces.Listener;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.credentials.HintRequest;
import com.google.android.gms.auth.api.phone.SmsRetriever;
import com.google.android.gms.auth.api.phone.SmsRetrieverClient;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;

public class MainActivity extends AppCompatActivity {
    private Listener listener;
    private SMSBroadcastReceiver smsBroadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        smsBroadcastReceiver = new SMSBroadcastReceiver();
        /*
First, You need the number of the user on which the OTP will be received,
you can get the user’s phone number through HintRequest in the onActivityResult().
         */
          /*HintRequest hintRequest = new HintRequest.Builder()
                .setPhoneNumberIdentifierSupported(true)
                .build();
        PendingIntent intent = Auth.CredentialsApi.getHintPickerIntent(
                apiClient, hintRequest);
        startIntentSenderForResult(intent.getIntentSender(), RESOLVE_HINT, null, 0, 0, 0);
        */
        requestHint();
    }

    private void requestHint() {


        try {
            SmsRetrieverClient client = SmsRetriever.getClient(MainActivity.this);
            Task<Void> task = client.startSmsRetriever();
            task.addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                    // Successfully started retriever, expect broadcast intent
                    // ...
                    listener = new Listener() {
                        @Override
                        public void onSMSReceived(String otp) {

                        }

                        @Override
                        public void onTimeOut() {

                        }
                    };
                    smsBroadcastReceiver.injectListener(listener);
                    registerReceiver(smsBroadcastReceiver, new IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION));

                }
            });
            task.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    // Failed to start retriever, inspect Exception for more details
                    // ...
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(smsBroadcastReceiver);
    }
    /*
In onActivityResult() you will receive the result of what user has selected.
If you do not get the number you can explicitly ask the user to enter the number to complete the registration flow
     */

    /*if (requestCode == RESOLVE_HINT) {
        if (resultCode == RESULT_OK) {
            Credential credential= data.getParcelableExtra(Credential.EXTRA_KEY);
            // credential.getId(); <-- will need to process phone number string
        }
    }*/
}
